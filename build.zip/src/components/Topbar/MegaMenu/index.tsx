import MegaMenuHome from './MegaMenuHome'
import MegaMenuApps from './MegaMenuApps'
import MegaMenuPages from './MegaMenuPages'
import MegaMenuAuth from './MegaMenuAuth'

export { MegaMenuHome, MegaMenuApps, MegaMenuPages, MegaMenuAuth }
