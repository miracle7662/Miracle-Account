export interface InvoiceItem {
  id: string
  date: string
  invnumber: string
  amount: string
  status: string
}
