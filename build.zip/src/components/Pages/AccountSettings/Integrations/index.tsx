import IntegrationsComponent from './IntegrationsComponent'

export { IntegrationsComponent }
