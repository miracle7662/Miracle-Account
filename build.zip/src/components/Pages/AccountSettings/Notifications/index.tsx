import NotificationsComponent from './NotificationsComponent'

export { NotificationsComponent }
