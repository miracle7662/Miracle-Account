import AccountComponent from './AccountComponent'

export { AccountComponent }
