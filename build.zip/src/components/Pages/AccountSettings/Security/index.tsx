import SecurityComponent from './SecurityComponent'

export { SecurityComponent }
