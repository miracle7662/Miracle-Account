import BillingComponent from './BillingComponent'

export { BillingComponent }
