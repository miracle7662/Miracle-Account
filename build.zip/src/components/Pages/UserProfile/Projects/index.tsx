import ProjectsComponent from './ProjectsComponent'

export { ProjectsComponent }
