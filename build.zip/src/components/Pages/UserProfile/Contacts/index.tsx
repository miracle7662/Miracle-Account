import ContactsComponent from './ContactsComponent'

export { ContactsComponent }
