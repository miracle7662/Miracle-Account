import ActivityComponent from './ActivityComponent'

export { ActivityComponent }
