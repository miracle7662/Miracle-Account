import FollowersComponent from './FollowersComponent'

export { FollowersComponent }
