interface gamesType {
  name: string
}

const Games: gamesType[] = [
  {
    name: 'Genshin Impact',
  },
  {
    name: 'Pokémon GO',
  },
  {
    name: 'Call of Duty',
  },
  {
    name: 'Resident Evil 4',
  },
  {
    name: 'Deathloop',
  },
]

export default Games
