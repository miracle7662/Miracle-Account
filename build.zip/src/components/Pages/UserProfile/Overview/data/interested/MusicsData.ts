interface musicsType {
  name: string
}

const Musics: musicsType[] = [
  {
    name: 'Wolf Hall',
  },
  {
    name: 'Normal People',
  },
  {
    name: 'A Spy Alone',
  },
  {
    name: 'Moscow X',
  },
  {
    name: 'Beirut Station',
  },
]

export default Musics
