interface booksType {
  name: string
}

const Books: booksType[] = [
  {
    name: 'The Box',
  },
  {
    name: 'Superbike',
  },
  {
    name: "If I Can't Have You",
  },
  {
    name: "Don't Start Now",
  },
  {
    name: 'Adore You',
  },
]

export default Books
