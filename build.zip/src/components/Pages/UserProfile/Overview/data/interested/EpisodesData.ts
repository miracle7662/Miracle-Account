interface episodesType {
  name: string
}

const Episodes: episodesType[] = [
  {
    name: 'Breaking Bad',
  },
  {
    name: 'Game of Thrones',
  },
  {
    name: 'Attack on Titan',
  },
  {
    name: 'Mr. Robot',
  },
  {
    name: 'Code Geass',
  },
]

export default Episodes
