interface hobbiesType {
  name: string
}

const Hobbies: hobbiesType[] = [
  {
    name: 'Gardening',
  },
  {
    name: 'Photography',
  },
  {
    name: 'Yoga',
  },
  {
    name: 'Hiking',
  },
  {
    name: 'Cooking',
  },
  {
    name: 'Coding',
  },
]

export default Hobbies
