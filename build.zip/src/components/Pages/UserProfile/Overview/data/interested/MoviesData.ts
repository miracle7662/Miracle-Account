interface moviesType {
  name: string
}

const Movies: moviesType[] = [
  {
    name: 'Parasite',
  },
  {
    name: 'Inception',
  },
  {
    name: 'The Godfather',
  },
  {
    name: 'The Dark Knight',
  },
  {
    name: 'The Matrix',
  },
]

export default Movies
