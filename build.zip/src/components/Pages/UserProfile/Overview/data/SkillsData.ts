interface skillsType {
  name: string
}

const Skills: skillsType[] = [
  {
    name: 'Frontend',
  },
  {
    name: 'Bootstrap',
  },
  {
    name: 'Taildwind',
  },
  {
    name: 'HTML5',
  },
  {
    name: 'CSS3',
  },
  {
    name: 'jQuery',
  },
  {
    name: 'React',
  },
  {
    name: 'Next',
  },
  {
    name: 'Nuxt',
  },
  {
    name: 'Vuejs',
  },
  {
    name: 'Angular',
  },
  {
    name: 'Laravel',
  },
  {
    name: 'Svelt',
  },
  {
    name: 'Gulpjs',
  },
  {
    name: 'SASS/SCSS',
  },
  {
    name: 'SEO',
  },
]

export default Skills
