import AllsGallery from './AllsGallery'
import GalleryOne from './GalleryOne'
import GalleryTwo from './GalleryTwo'
import GalleryThree from './GalleryThree'

export { AllsGallery, GalleryOne, GalleryTwo, GalleryThree }
