import PricingTable from './PricingTable'

export { PricingTable }
