import PrivacyPolicyContent from './PrivacyPolicyContent'

export { PrivacyPolicyContent }
