import TermsServicesContent from './TermsServicesContent'

export { TermsServicesContent }
