import AboutCompany from './AboutCompany'
import AboutCount from './AboutCount'
import AboutBrands from './AboutBrands'
import AboutQuote from './AboutQuote'
import AboutTeam from './AboutTeam'
import AboutOffice from './AboutOffice'

export { AboutCompany, AboutCount, AboutBrands, AboutQuote, AboutTeam, AboutOffice }
