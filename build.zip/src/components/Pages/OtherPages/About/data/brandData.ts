import facebook from '@/assets/images/logos/facebook.svg'
import google from '@/assets/images/logos/google.svg'
import linkedin from '@/assets/images/logos/linkedin.svg'
import microsoft from '@/assets/images/logos/microsoft.svg'
import msoffice from '@/assets/images/logos/msoffice.svg'

const brandData = [
  {
    image: microsoft,
  },
  {
    image: google,
  },
  {
    image: linkedin,
  },
  {
    image: facebook,
  },
  {
    image: google,
  },
  {
    image: msoffice,
  },
  {
    image: facebook,
  },
  {
    image: microsoft,
  },
  {
    image: facebook,
  },
  {
    image: google,
  },
  {
    image: msoffice,
  },
  {
    image: google,
  },
]

export default brandData
